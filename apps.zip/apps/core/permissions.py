from rest_framework import permissions

class IsSchoolUser(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user and request.user.is_authenticated and request.user.school is not None
