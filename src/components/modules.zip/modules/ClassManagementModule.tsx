import { useState, useEffect } from 'react';
import { Plus, Search, Users, BookOpen, Settings, TrendingUp, Filter, Trash2, UserPlus, AlertCircle, Printer } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Class, Stream, ClassStats, ClassFilters, StreamFilters, CLASS_GROUPS } from '@/types/class';
import { classService } from '@/services/classService';
import { streamSettingsService } from '@/services/streamSettingsService';
import { StreamNameSetting } from '@/types/stream-settings';
import { api } from '@/api/api';
import { supabase } from '@/integrations/supabase/client';
import { ClassSubjectsTab } from './ClassSubjectsTab';

export const ClassManagementModule = () => {
  const { toast } = useToast();
  const [classes, setClasses] = useState<Class[]>([]);
  const [streams, setStreams] = useState<Stream[]>([]);
  const [streamNames, setStreamNames] = useState<StreamNameSetting[]>([]);
  const [stats, setStats] = useState<ClassStats | null>(null);
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState<ClassFilters>({});
  const [streamFilters, setStreamFilters] = useState<StreamFilters>({});
  const [isCreateClassOpen, setIsCreateClassOpen] = useState(false);
  const [isCreateStreamOpen, setIsCreateStreamOpen] = useState(false);
  const [isEditClassOpen, setIsEditClassOpen] = useState(false);
  const [editClassForm, setEditClassForm] = useState({ name: '', grade_level: 1, description: '', capacity: 40 });
  const [selectedClass, setSelectedClass] = useState<Class | null>(null);
  const [isAssignTeacherOpen, setIsAssignTeacherOpen] = useState(false);
  const [selectedStream, setSelectedStream] = useState<Stream | null>(null);
  const [teachers, setTeachers] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);
  const [allocations, setAllocations] = useState<any[]>([]);
  const [allocationStreamFilter, setAllocationStreamFilter] = useState<string>('all');
  const [fixingAll, setFixingAll] = useState(false);
  const [fixingStudentId, setFixingStudentId] = useState<string | null>(null);

  // Form states
  const [classForm, setClassForm] = useState({
    name: '',
    grade_level: 1,
    description: ''
  });
  
  const [streamForm, setStreamForm] = useState({
    name: '',
    class_assigned: '',
    year: new Date().getFullYear(),
    capacity: 40,
    class_teacher: '',
    status: 'active' as const
  });

  useEffect(() => {
    loadData();
  }, [filters, streamFilters]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [classData, streamData, statsData, streamNamesData] = await Promise.all([
        classService.getClasses(filters),
        classService.getStreams(streamFilters),
        classService.getClassStats(),
        streamSettingsService.getStreamNames()
      ]);
      
      // Load students and teachers directly from Supabase
      const [studentsResult, teachersResult] = await Promise.all([
        supabase
          .from('students')
          .select('*')
          .eq('is_active', true)
          .order('admission_number'),
        supabase
          .from('teachers')
          .select('id, first_name, last_name, employee_no')
          .eq('is_active', true)
          .order('first_name')
      ]);
      
      setClasses(classData);
      setStreams(streamData);
      setStats(statsData);
      setStreamNames(streamNamesData);
      setTeachers(teachersResult.data || []);
      setStudents(studentsResult.data || []);
    } catch (error) {
      console.error('Load data error:', error);
      toast({
        title: "Error",
        description: "Failed to load class data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Clear stream assignment for mismatched students
  const clearStudentStream = async (studentIds: (string | number)[]) => {
    const { error } = await supabase
      .from('students')
      .update({ current_stream_id: null })
      .in('id', studentIds);
    if (error) throw error;
  };

  const handleCreateClass = async () => {
    if (!classForm.name.trim()) {
      toast({
        title: "Error",
        description: "Class name is required",
        variant: "destructive",
      });
      return;
    }

    try {
      await classService.createClass({
        name: classForm.name.trim(),
        grade_level: classForm.grade_level,
        description: classForm.description
      });
      
      toast({
        title: "Success",
        description: "Class created successfully",
      });
      
      setIsCreateClassOpen(false);
      setClassForm({ name: '', grade_level: 1, description: '' });
      loadData();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to create class",
        variant: "destructive",
      });
    }
  };

  const handleCreateStream = async () => {
    if (!streamForm.name.trim() || !streamForm.class_assigned) {
      toast({
        title: "Error",
        description: "Stream name and class are required",
        variant: "destructive",
      });
      return;
    }

    try {
      await classService.createStream({
        name: streamForm.name.trim(),
        class_assigned: streamForm.class_assigned,
        year: streamForm.year,
        capacity: streamForm.capacity,
        status: streamForm.status
      });
      
      toast({
        title: "Success",
        description: "Stream created successfully",
      });
      
      setIsCreateStreamOpen(false);
      setStreamForm({
        name: '',
        class_assigned: '',
        year: new Date().getFullYear(),
        capacity: 40,
        class_teacher: '',
        status: 'active'
      });
      loadData();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to create stream",
        variant: "destructive",
      });
    }
  };

  const handleOpenEditClass = (cls: Class) => {
    setSelectedClass(cls);
    setEditClassForm({
      name: cls.name || '',
      grade_level: cls.grade_level || 1,
      description: cls.description || '',
      capacity: cls.capacity || 40,
    });
    setIsEditClassOpen(true);
  };

  const handleUpdateClass = async () => {
    if (!selectedClass) return;
    try {
      await classService.updateClass(selectedClass.id, editClassForm);
      toast({ title: 'Success', description: 'Class updated successfully' });
      setIsEditClassOpen(false);
      loadData();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to update class',
        variant: 'destructive',
      });
    }
  };

  const handleDeleteClass = async (classId: string) => {
    if (!window.confirm('Are you sure you want to delete this class? This will also delete all associated streams.')) {
      return;
    }

    try {
      await classService.deleteClass(classId);
      toast({
        title: "Success",
        description: "Class deleted successfully",
      });
      loadData();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to delete class. It may have students assigned to it.",
        variant: "destructive",
      });
    }
  };

  const handleDeleteStream = async (streamId: string) => {
    if (!window.confirm('Are you sure you want to delete this stream?')) {
      return;
    }

    try {
      await classService.deleteStream(streamId);
      toast({
        title: "Success",
        description: "Stream deleted successfully",
      });
      loadData();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to delete stream. It may have students assigned to it.",
        variant: "destructive",
      });
    }
  };

  const handleAssignTeacher = async (teacherId: string) => {
    if (!selectedStream) return;

    try {
      await api.patch(`/students/streams/${selectedStream.id}/`, {
        class_teacher: teacherId
      });
      
      toast({
        title: "Success",
        description: "Class teacher assigned successfully",
      });
      
      setIsAssignTeacherOpen(false);
      setSelectedStream(null);
      loadData();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to assign teacher",
        variant: "destructive",
      });
    }
  };

  const getClassGroupLabel = (gradeLevel: number) => {
    const group = CLASS_GROUPS.find(g => g.levels.includes(gradeLevel));
    return group?.label || 'Other';
  };

  const getCapacityColor = (enrollment: number, capacity: number) => {
    const ratio = enrollment / capacity;
    if (ratio >= 0.9) return 'bg-red-100 text-red-800';
    if (ratio >= 0.7) return 'bg-yellow-100 text-yellow-800';
    return 'bg-green-100 text-green-800';
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Class Management</h1>
          <p className="text-muted-foreground">
            Manage classes, streams, and student allocations
          </p>
        </div>
        
        <div className="flex gap-2">
          <Dialog open={isCreateStreamOpen} onOpenChange={setIsCreateStreamOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <Plus className="mr-2 h-4 w-4" />
                Add Stream
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Stream</DialogTitle>
                <DialogDescription>
                  Add a new stream to an existing class.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="stream-name">Stream Name</Label>
                  <Select
                    value={streamForm.name}
                    onValueChange={(value) => setStreamForm(prev => ({ ...prev, name: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select stream name" />
                    </SelectTrigger>
                    <SelectContent>
                      {streamNames.length === 0 ? (
                        <div className="p-2 text-sm text-muted-foreground">
                          No stream names configured. Please add stream names in Settings.
                        </div>
                      ) : (
                        streamNames.map((streamName) => (
                          <SelectItem key={streamName.id} value={streamName.name}>
                            {streamName.name}
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="stream-class">Class</Label>
                  <Select
                    value={streamForm.class_assigned}
                    onValueChange={(value) => setStreamForm(prev => ({ ...prev, class_assigned: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select class" />
                    </SelectTrigger>
                    <SelectContent>
                      {classes.map((cls) => (
                        <SelectItem key={cls.id} value={cls.id}>
                          {cls.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="stream-year">Academic Year</Label>
                    <Input
                      id="stream-year"
                      type="number"
                      value={streamForm.year}
                      onChange={(e) => setStreamForm(prev => ({ ...prev, year: parseInt(e.target.value) }))}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="stream-capacity">Capacity</Label>
                    <Input
                      id="stream-capacity"
                      type="number"
                      value={streamForm.capacity}
                      onChange={(e) => setStreamForm(prev => ({ ...prev, capacity: parseInt(e.target.value) }))}
                    />
                  </div>
                </div>
                <Button onClick={handleCreateStream} className="w-full">
                  Create Stream
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={isCreateClassOpen} onOpenChange={setIsCreateClassOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Add Class
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Class</DialogTitle>
                <DialogDescription>
                  Add a new class to your school.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="class-name">Class Name</Label>
                  <Input
                    id="class-name"
                    value={classForm.name}
                    onChange={(e) => setClassForm(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g., Grade 1, Form 2"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="grade-level">Grade Level</Label>
                  <Input
                    id="grade-level"
                    type="number"
                    min="1"
                    max="12"
                    value={classForm.grade_level}
                    onChange={(e) => setClassForm(prev => ({ ...prev, grade_level: parseInt(e.target.value) }))}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="class-description">Description</Label>
                  <Textarea
                    id="class-description"
                    value={classForm.description}
                    onChange={(e) => setClassForm(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Optional description"
                  />
                </div>
                <Button onClick={handleCreateClass} className="w-full">
                  Create Class
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          {/* Edit Class Dialog */}
          <Dialog open={isEditClassOpen} onOpenChange={setIsEditClassOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Edit Class</DialogTitle>
                <DialogDescription>
                  Update the details for {selectedClass?.name}.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="edit-class-name">Class Name</Label>
                  <Input
                    id="edit-class-name"
                    value={editClassForm.name}
                    onChange={(e) => setEditClassForm(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g., Grade 1, Form 2"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="edit-grade-level">Grade Level</Label>
                  <Input
                    id="edit-grade-level"
                    type="number"
                    min="1"
                    max="12"
                    value={editClassForm.grade_level}
                    onChange={(e) => setEditClassForm(prev => ({ ...prev, grade_level: parseInt(e.target.value) }))}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="edit-capacity">Capacity</Label>
                  <Input
                    id="edit-capacity"
                    type="number"
                    min="1"
                    value={editClassForm.capacity}
                    onChange={(e) => setEditClassForm(prev => ({ ...prev, capacity: parseInt(e.target.value) }))}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="edit-class-description">Description</Label>
                  <Textarea
                    id="edit-class-description"
                    value={editClassForm.description}
                    onChange={(e) => setEditClassForm(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Optional description"
                  />
                </div>
                <Button onClick={handleUpdateClass} className="w-full">
                  Save Changes
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Statistics Cards */}
      {stats && (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Classes</CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total_classes}</div>
              <p className="text-xs text-muted-foreground">
                Across all grade levels
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Streams</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total_streams}</div>
              <p className="text-xs text-muted-foreground">
                Active streams
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Students</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total_students_enrolled}</div>
              <p className="text-xs text-muted-foreground">
                Currently enrolled
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Capacity Used</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.capacity_utilization}%</div>
              <p className="text-xs text-muted-foreground">
                Average utilization
              </p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Main Content */}
      <Tabs defaultValue="classes" className="space-y-4">
        <TabsList>
          <TabsTrigger value="classes">Classes</TabsTrigger>
          <TabsTrigger value="streams">Streams</TabsTrigger>
          <TabsTrigger value="subjects">Class Subjects</TabsTrigger>
          <TabsTrigger value="allocations">Student Allocations</TabsTrigger>
        </TabsList>

        <TabsContent value="classes" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle>Classes</CardTitle>
              <CardDescription>Manage your school classes and grade levels</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4 mb-4">
                <div className="flex-1">
                  <Input
                    placeholder="Search classes..."
                    value={filters.search || ''}
                    onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
                    className="max-w-sm"
                  />
                </div>
                <Select
                  value={filters.grade_level?.toString() || 'all'}
                  onValueChange={(value) => setFilters(prev => ({ 
                    ...prev, 
                    grade_level: value === 'all' ? undefined : parseInt(value) 
                  }))}
                >
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="All Grade Levels" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Grade Levels</SelectItem>
                    {Array.from({ length: 12 }, (_, i) => (
                      <SelectItem key={i + 1} value={(i + 1).toString()}>
                        Grade {i + 1}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Classes Table */}
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Class Name</TableHead>
                    <TableHead>Grade Level</TableHead>
                    <TableHead>Group</TableHead>
                    <TableHead>Streams</TableHead>
                    <TableHead>Students</TableHead>
                    <TableHead>Capacity</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {classes.map((cls) => (
                    <TableRow key={cls.id}>
                      <TableCell className="font-medium">{cls.name}</TableCell>
                      <TableCell>{cls.grade_level}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">
                          {getClassGroupLabel(cls.grade_level)}
                        </Badge>
                      </TableCell>
                      <TableCell>{cls.total_streams || 0}</TableCell>
                      <TableCell>{cls.total_students || 0}</TableCell>
                      <TableCell>
                        <Badge className={getCapacityColor(cls.total_students || 0, cls.capacity || 0)}>
                          {cls.total_students || 0}/{cls.capacity || 0}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button variant="ghost" size="sm" onClick={() => handleOpenEditClass(cls)}>
                            <Settings className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleDeleteClass(cls.id)}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="streams" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Streams</CardTitle>
              <CardDescription>Manage class streams and their allocations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4 mb-4">
                <Input
                  placeholder="Search streams..."
                  value={streamFilters.search || ''}
                  onChange={(e) => setStreamFilters(prev => ({ ...prev, search: e.target.value }))}
                  className="max-w-sm"
                />
                <Select
                  value={streamFilters.class_id?.toString() || 'all'}
                  onValueChange={(value) => setStreamFilters(prev => ({ 
                    ...prev, 
                    class_id: value === 'all' ? undefined : value 
                  }))}
                >
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="All Classes" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Classes</SelectItem>
                    {classes.map((cls) => (
                      <SelectItem key={cls.id} value={cls.id.toString()}>
                        {cls.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Streams Table */}
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Stream</TableHead>
                    <TableHead>Class</TableHead>
                    <TableHead>Year</TableHead>
                    <TableHead>Class Teacher</TableHead>
                    <TableHead>Enrollment</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {streams.map((stream) => (
                    <TableRow key={stream.id}>
                      <TableCell className="font-medium">{stream.name}</TableCell>
                      <TableCell>{stream.class_name}</TableCell>
                      <TableCell>{stream.year}</TableCell>
                      <TableCell>{stream.class_teacher_name || 'Not assigned'}</TableCell>
                      <TableCell>
                        <Badge className={getCapacityColor(stream.current_enrollment, stream.capacity)}>
                          {stream.current_enrollment}/{stream.capacity}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={stream.status === 'active' ? 'default' : 'secondary'}>
                          {stream.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => {
                              setSelectedStream(stream);
                              setIsAssignTeacherOpen(true);
                            }}
                          >
                            <UserPlus className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => handleDeleteStream(stream.id)}
                            className="text-destructive hover:text-destructive"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="subjects" className="space-y-4">
          <ClassSubjectsTab 
            classes={classes.map(c => ({ id: c.id, name: c.name, grade_level: c.grade_level }))} 
            teachers={teachers}
          />
        </TabsContent>

        <TabsContent value="allocations" className="space-y-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Student Allocations</CardTitle>
                <CardDescription>View students allocated to each class and stream</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => window.print()}
                >
                  <Printer className="mr-2 h-4 w-4" />
                  Print List
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4 mb-4 print:hidden">
                <Select
                  value={filters.grade_level?.toString() || 'all'}
                  onValueChange={(value) => setFilters(prev => ({ 
                    ...prev, 
                    grade_level: value === 'all' ? undefined : parseInt(value) 
                  }))}
                >
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="All Grade Levels" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Grade Levels</SelectItem>
                    {Array.from({ length: 12 }, (_, i) => (
                      <SelectItem key={i + 1} value={(i + 1).toString()}>
                        Grade {i + 1}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select
                  value={allocationStreamFilter}
                  onValueChange={setAllocationStreamFilter}
                >
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="All Streams" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Streams</SelectItem>
                    {streams
                      .filter(s => !filters.grade_level || classes.find(c => String(c.id) === String(s.class_assigned) && c.grade_level === filters.grade_level))
                      .map((stream) => (
                        <SelectItem key={stream.id} value={stream.id}>
                          {stream.class_name} - {stream.name}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>

              {(() => {
                // Helper: infer stream name from class name when current_stream_id is absent.
                // e.g. "Primary Grade 6 Blue" → "Blue" given streams [{name:"Blue",...}]
                const inferStreamFromClassName = (className: string, classStreams: any[]): string | null => {
                  for (const s of classStreams) {
                    const regex = new RegExp(`\\b${s.name}\\b`, 'i');
                    if (regex.test(className)) return s.name;
                  }
                  return null;
                };

                // Mismatched students (global — not filtered, so banner always accurate)
                const mismatchedStudents = students.filter(student => {
                  const studentClass = classes.find(c => String(c.id) === String(student.current_class_id));
                  const studentStream = streams.find(s => String(s.id) === String(student.current_stream_id));
                  if (studentClass && studentStream) {
                    return String(studentStream.class_assigned) !== String(studentClass.id);
                  }
                  return false;
                });

                // Apply grade level filter
                let filteredStudents = students.filter(student => {
                  if (!filters.grade_level) return true;
                  const studentClass = classes.find(c => String(c.id) === String(student.current_class_id));
                  return studentClass?.grade_level === filters.grade_level;
                });

                // Apply stream filter — match on stream_id OR inferred stream name from class name
                if (allocationStreamFilter !== 'all') {
                  const selectedStream = streams.find(s => String(s.id) === String(allocationStreamFilter));
                  filteredStudents = filteredStudents.filter(student => {
                    if (String(student.current_stream_id) === String(allocationStreamFilter)) return true;
                    if (selectedStream) {
                      const studentClass = classes.find(c => String(c.id) === String(student.current_class_id));
                      if (studentClass) {
                        const classStreams = streams.filter(s => String(s.class_assigned) === String(studentClass.id));
                        return inferStreamFromClassName(studentClass.name, classStreams) === selectedStream.name;
                      }
                    }
                    return false;
                  });
                }

                if (students.length === 0) {
                  return (
                    <div className="text-center py-8">
                      <Users className="mx-auto h-12 w-12 text-muted-foreground" />
                      <h3 className="mt-4 text-lg font-semibold">No Students Found</h3>
                      <p className="text-muted-foreground">
                        No students have been allocated to classes yet.
                      </p>
                    </div>
                  );
                }

                // Group by class then stream.
                // Priority: explicit current_stream_id → infer from class name → "No Stream"
                const groupedStudents = filteredStudents.reduce((acc, student) => {
                  const studentClass = classes.find(c => String(c.id) === String(student.current_class_id));
                  if (!studentClass) return acc;
                  const studentStream = streams.find(s => String(s.id) === String(student.current_stream_id));
                  const classKey = studentClass.name;
                  let streamKey: string;
                  if (studentStream) {
                    streamKey = studentStream.name;
                  } else {
                    const classStreams = streams.filter(s => String(s.class_assigned) === String(studentClass.id));
                    streamKey = inferStreamFromClassName(studentClass.name, classStreams) || 'No Stream';
                  }
                  if (!acc[classKey]) acc[classKey] = {};
                  if (!acc[classKey][streamKey]) acc[classKey][streamKey] = [];
                  acc[classKey][streamKey].push(student);
                  return acc;
                }, {} as Record<string, Record<string, any[]>>);

                return (
                  <div className="space-y-6">
                    {/* Mismatch banner — shown above table, never replaces it */}
                    {mismatchedStudents.length > 0 && (
                      <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4 print:hidden">
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-start gap-3">
                            <AlertCircle className="h-5 w-5 text-yellow-600 dark:text-yellow-500 mt-0.5 shrink-0" />
                            <div>
                              <h4 className="font-semibold text-yellow-900 dark:text-yellow-100">Data Mismatch Detected</h4>
                              <p className="text-sm text-yellow-800 dark:text-yellow-200 mt-1">
                                {mismatchedStudents.length} student(s) are assigned to streams that belong to different classes.
                                Clearing the stream assignment lets you reassign them correctly.
                              </p>
                            </div>
                          </div>
                          <Button
                            size="sm"
                            variant="outline"
                            className="shrink-0 border-yellow-500 text-yellow-800 hover:bg-yellow-100"
                            disabled={fixingAll}
                            onClick={async () => {
                              setFixingAll(true);
                              try {
                                await clearStudentStream(mismatchedStudents.map(s => s.id));
                                await loadData();
                                toast({ title: 'Fixed', description: `Stream cleared for ${mismatchedStudents.length} student(s).` });
                              } catch {
                                toast({ title: 'Error', description: 'Failed to fix mismatches.', variant: 'destructive' });
                              } finally {
                                setFixingAll(false);
                              }
                            }}
                          >
                            {fixingAll ? 'Fixing…' : `Fix All (${mismatchedStudents.length})`}
                          </Button>
                        </div>
                        <Table className="mt-3">
                          <TableHeader>
                            <TableRow>
                              <TableHead>Admission No.</TableHead>
                              <TableHead>Student Name</TableHead>
                              <TableHead>Assigned Class</TableHead>
                              <TableHead>Assigned Stream</TableHead>
                              <TableHead>Stream's Class</TableHead>
                              <TableHead>Action</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {mismatchedStudents.map((student) => {
                              const studentClass = classes.find(c => String(c.id) === String(student.current_class_id));
                              const studentStream = streams.find(s => String(s.id) === String(student.current_stream_id));
                              const isFixing = fixingStudentId === String(student.id);
                              return (
                                <TableRow key={student.id}>
                                  <TableCell className="font-medium">{student.admission_number}</TableCell>
                                  <TableCell>{student.full_name}</TableCell>
                                  <TableCell>{studentClass?.name || 'N/A'}</TableCell>
                                  <TableCell>{studentStream?.name || 'N/A'}</TableCell>
                                  <TableCell>{studentStream?.class_name || 'N/A'}</TableCell>
                                  <TableCell>
                                    <div className="flex items-center gap-2">
                                      <Badge variant="destructive">Mismatch</Badge>
                                      <Button
                                        size="sm"
                                        variant="ghost"
                                        className="h-7 px-2 text-xs text-destructive hover:text-destructive hover:bg-red-50"
                                        disabled={isFixing || fixingAll}
                                        onClick={async () => {
                                          setFixingStudentId(String(student.id));
                                          try {
                                            await clearStudentStream([student.id]);
                                            await loadData();
                                            toast({ title: 'Fixed', description: `Stream cleared for ${student.full_name}.` });
                                          } catch {
                                            toast({ title: 'Error', description: 'Failed to fix student.', variant: 'destructive' });
                                          } finally {
                                            setFixingStudentId(null);
                                          }
                                        }}
                                      >
                                        {isFixing ? 'Fixing…' : 'Clear Stream'}
                                      </Button>
                                    </div>
                                  </TableCell>
                                </TableRow>
                              );
                            })}
                          </TableBody>
                        </Table>
                      </div>
                    )}

                    {/* Print Header */}
                    <div className="hidden print:block mb-6">
                      <h2 className="text-2xl font-bold text-center">Student Allocation List</h2>
                      <p className="text-center text-muted-foreground">
                        {filters.grade_level ? `Grade ${filters.grade_level}` : 'All Grades'}
                        {allocationStreamFilter !== 'all' && ` - ${streams.find(s => s.id === allocationStreamFilter)?.name}`}
                      </p>
                      <p className="text-center text-sm text-muted-foreground mt-2">
                        Generated: {new Date().toLocaleDateString()}
                      </p>
                    </div>

                    {filteredStudents.length === 0 ? (
                      <div className="text-center py-8">
                        <Users className="mx-auto h-12 w-12 text-muted-foreground" />
                        <h3 className="mt-4 text-lg font-semibold">No Students Found</h3>
                        <p className="text-muted-foreground">
                          {allocationStreamFilter !== 'all'
                            ? 'No students found for the selected stream'
                            : filters.grade_level
                              ? `No students found for Grade ${filters.grade_level}`
                              : 'No students found'
                          }
                        </p>
                      </div>
                    ) : (
                      Object.entries(groupedStudents).map(([className, streamGroups]) => (
                        <div key={className} className="space-y-4">
                          <h3 className="text-xl font-semibold border-b pb-2">{className}</h3>
                          {Object.entries(streamGroups).map(([streamName, streamStudents]) => (
                            <div key={streamName} className="mb-6 page-break-inside-avoid">
                              <div className="flex items-center justify-between mb-2">
                                <h4 className="text-lg font-medium text-muted-foreground">
                                  {streamName} ({streamStudents.length} student{streamStudents.length !== 1 ? 's' : ''})
                                </h4>
                              </div>
                              <Table>
                                <TableHeader>
                                  <TableRow>
                                    <TableHead className="w-12">#</TableHead>
                                    <TableHead>Admission No.</TableHead>
                                    <TableHead>Student Name</TableHead>
                                    <TableHead>Gender</TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {streamStudents
                                    .sort((a, b) => a.admission_number.localeCompare(b.admission_number))
                                    .map((student, index) => (
                                      <TableRow key={student.id}>
                                        <TableCell className="font-medium">{index + 1}</TableCell>
                                        <TableCell>{student.admission_number}</TableCell>
                                        <TableCell>{student.full_name}</TableCell>
                                        <TableCell>
                                          <Badge variant="outline">{student.gender}</Badge>
                                        </TableCell>
                                      </TableRow>
                                    ))}
                                </TableBody>
                              </Table>
                            </div>
                          ))}
                        </div>
                      ))
                    )}
                  </div>
                );
              })()}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Assign Teacher Dialog */}
      <Dialog open={isAssignTeacherOpen} onOpenChange={setIsAssignTeacherOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Assign Class Teacher</DialogTitle>
            <DialogDescription>
              Select a teacher to assign to {selectedStream?.name} - {selectedStream?.class_name}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label>Select Teacher</Label>
              <Select
                onValueChange={(value) => handleAssignTeacher(value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Choose a teacher" />
                </SelectTrigger>
                <SelectContent>
                  {teachers.length === 0 ? (
                    <div className="p-2 text-sm text-muted-foreground">
                      No teachers available. Please add teachers first.
                    </div>
                  ) : (
                    teachers.map((teacher) => (
                      <SelectItem key={teacher.id} value={teacher.id.toString()}>
                        {teacher.first_name} {teacher.last_name} - TSC: {teacher.tsc_number}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};